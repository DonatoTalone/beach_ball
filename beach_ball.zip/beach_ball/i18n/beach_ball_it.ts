<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT" sourcelanguage="en">
<context>
    <name>BeachBall</name>
    <message>
        <location filename="../beach_ball.py" line="184"/>
        <source>&amp;BeachBall</source>
        <translation>BeachBall</translation>
    </message>
    <message>
        <location filename="../beach_ball.py" line="172"/>
        <source>Draw beachball for focal mechanisms</source>
        <translation>Disegna il meccanismo focale come beachball</translation>
    </message>
</context>
<context>
    <name>BeachBallDialogBase</name>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="20"/>
        <source>BeachBall</source>
        <translation>BeachBall</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="26"/>
        <source>Select a Layer:</source>
        <translation>Seleziona un Layer</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="36"/>
        <source>NF color:</source>
        <translation>Colore per NF</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="43"/>
        <source>ID field:</source>
        <translation>Campo ID</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="53"/>
        <source>NS color:</source>
        <translation>Colore per NS</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="60"/>
        <source>Strike field:</source>
        <translation>Campo Direzione</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="70"/>
        <source>SS color:</source>
        <translation>Colore per SS</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="77"/>
        <source>Dip field:</source>
        <translation>Campo Inclinazione</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="87"/>
        <source>TS color:</source>
        <translation>Colore per TS</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="94"/>
        <source>Rake field:</source>
        <translation>Campo Rake</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="104"/>
        <source>TF color:</source>
        <translation>Colore per TF</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="111"/>
        <source>Select output folder:</source>
        <translation>Seleziona la cartella di output</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="121"/>
        <source>...</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../beach_ball_dialog_base.ui" line="166"/>
        <source>PushButton</source>
        <translation></translation>
    </message>
</context>
</TS>
