int buf_init(void);
int buf_putchar(char);
int buf_dump(FILE *);
int buf_free(void);
