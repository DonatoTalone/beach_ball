# -*- coding: utf-8 -*-
"""
obspy.io.quakeml - QuakeML read and write support for ObsPy
===========================================================

:copyright:
    The ObsPy Development Team (devs@obspy.org)
:license:
    GNU Lesser General Public License, Version 3
    (https://www.gnu.org/copyleft/lesser.html)
"""
