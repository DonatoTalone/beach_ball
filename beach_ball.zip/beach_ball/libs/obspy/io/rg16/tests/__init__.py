MODULE_NAME = "obspy.io.rg16"
