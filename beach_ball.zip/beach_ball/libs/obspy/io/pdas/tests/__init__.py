# -*- coding: utf-8 -*-
MODULE_NAME = "obspy.io.pdas"
